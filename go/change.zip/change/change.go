package change

//import (
//	"errors"
//	"log"
//)


//func Solution(N int, A, B []int) int {
//	return 0
//}
